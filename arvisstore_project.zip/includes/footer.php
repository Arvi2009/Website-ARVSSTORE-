<footer>
    <p>&copy; 2024 Arvisstore. All rights reserved.</p>
</footer>

</body>
</html>
