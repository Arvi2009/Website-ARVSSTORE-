<?php include('../includes/header.php'); ?>

<div class="container">
    <div class="product-detail">
        <img src="../assets/images/product1.jpg" alt="Gaming Laptop">
        <h1>Gaming Laptop</h1>
        <p>Price: $1000</p>
        <p>This gaming laptop is perfect for all your gaming needs. High-performance specs and sleek design.</p>
        <button>Add to Cart</button>
    </div>
</div>

<?php include('../includes/footer.php'); ?>
