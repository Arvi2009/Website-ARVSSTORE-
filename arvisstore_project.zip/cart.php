<?php include('includes/header.php'); ?>

<div class="container">
    <h1>Your Shopping Cart</h1>
    <table>
        <tr>
            <th>Product</th>
            <th>Price</th>
            <th>Action</th>
        </tr>
        <tr>
            <td>Gaming Laptop</td>
            <td>$1000</td>
            <td><button>Remove</button></td>
        </tr>
        <tr>
            <td>Gaming Headset</td>
            <td>$150</td>
            <td><button>Remove</button></td>
        </tr>
    </table>
    <p>Total: $1150</p>
    <a href="checkout.php"><button>Proceed to Checkout</button></a>
</div>

<?php include('includes/footer.php'); ?>
