<?php include('includes/header.php'); ?>

<div class="container">
    <h1>Welcome to Arvisstore</h1>
    <p>Your one-stop shop for all things gaming.</p>

    <div class="product-list">
        <!-- Example Product 1 -->
        <div class="product">
            <img src="assets/images/product1.jpg" alt="Product 1">
            <h2>Gaming Laptop</h2>
            <p>$1000</p>
            <a href="products/product1.php">View Details</a>
        </div>
        
        <!-- Example Product 2 -->
        <div class="product">
            <img src="assets/images/product2.jpg" alt="Product 2">
            <h2>Gaming Headset</h2>
            <p>$150</p>
            <a href="products/product2.php">View Details</a>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>
