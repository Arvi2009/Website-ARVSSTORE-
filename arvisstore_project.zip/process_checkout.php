<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $address = $_POST['address'];
    $payment_method = $_POST['payment'];

    // Simulasi proses checkout
    echo "Thank you for your order, $name! Your order will be shipped to $address using $payment_method.";
}
?>
