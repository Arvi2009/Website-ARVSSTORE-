<?php include('includes/header.php'); ?>

<div class="container">
    <h1>Checkout</h1>
    <form action="process_checkout.php" method="POST">
        <label for="name">Full Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="address">Shipping Address:</label>
        <input type="text" id="address" name="address" required>

        <label for="payment">Payment Method:</label>
        <select id="payment" name="payment">
            <option value="paypal">PayPal</option>
            <option value="credit_card">Credit Card</option>
        </select>

        <button type="submit">Place Order</button>
    </form>
</div>

<?php include('includes/footer.php'); ?>
